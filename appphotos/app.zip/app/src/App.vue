<template>
  <div id="app">
    <div class="container">
      <div class="row mb-3" >
        <select class="custom-select custom-select-sm" v-model="itemCount">
          <option value="15" selected>15 photo / page</option>
          <option value="30">30 photo / page</option>
          <option value="45">45 photo / page</option>
          <option value="60">60 photo / page</option>
        </select>
      </div>
      <div class="row">
        <li class="col-md-4 col-sm-6 mt-0 pl-1 pr-1 mb-2"
        v-for="(link, index) in links.slice((pageNUmber - 1) * itemCount, pageNUmber * itemCount)" :key="index">
          <a :href="link" data-lightbox="image-lightbox">
            <div class="w-100 thumbnall"
            :style="{ 'background-image': 'url(' + link + ')' }"
            ></div>
          </a>
        </li>
      </div>
      <div class="row d-flex justify-content-center mt-3">
        <button class="btn btn-primary mr-1" @click="prev">Prev</button>
        <button class="btn btn-primary ml-1" @click="next">Next</button>
      </div>
    </div>
  </div>
</template>2

<script>
import axios from 'axios';
const url = "https://farebasebyap.firebaseio.com/link.json";
export default {
  name: 'App',
  data: function() {
    return {
        links: [],
        pageNUmber: 1,
        itemCount: 15
    }
  },
  mounted: function() {
    axios.get(url)
    .then((data) => {
      for (let key in data.data) {
         this.links.push(data.data[key]);
      }
      this.links = this.links[0]
    })
    .catch((error) => {
      console.log(error);
    })
  },
  methods: {
    prev: function(){
      if(this.pageNUmber > 1) {
        this.pageNUmber -= 1;
      }
    },
    next: function(){
      this.pageNUmber += 1;
    }
  }
}
</script>

<style>
li {
  list-style: none !important;
}
a {
  text-decoration: none !important;
}
.container {
  max-width: 1150px !important;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
.thumbnall {
  width: 293px;
  height: 293px;
  background-size: cover;
  background-position: top center;
  background-repeat: no-repeat;
}
</style>
